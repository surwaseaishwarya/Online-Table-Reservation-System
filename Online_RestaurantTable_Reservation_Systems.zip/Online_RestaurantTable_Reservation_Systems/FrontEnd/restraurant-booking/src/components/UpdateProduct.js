import React, { Component } from 'react';
import Header from './Header';

class updateProduct extends Component {
           
         constructor() {
             super();
             this.state = {
                 bookings:[],
             }
         }

         componentWillMount() {
             console.log("in will mount ........");
         }
  




    render() {
        return (
            <div>
                <Header/>
                <h1> Post Table data : </h1>
                 <form>
                     <label> Name :</label>
                     <input type="text" placeholder="Enter the name "></input>
                 </form>
           </div>
            
        );
    }
}

export default updateProduct;
