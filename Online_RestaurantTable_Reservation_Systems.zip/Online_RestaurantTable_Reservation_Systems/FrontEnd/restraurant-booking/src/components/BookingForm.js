import React, { Component } from 'react';

import axios from 'axios';
class BookingForm extends Component {

    constructor() {
        super();
        this.state = {
          bookings: [],
          
    
        };
      }
    
      
      componentDidMount() {

        const id=''
        let usr=localStorage.getItem("user");
        var userId = JSON.parse(usr).id;
    
        axios.get(`http://localhost:8080/bookings/getuser/${userId}`)
        .then((response) => {
             this.setState({
               bookings:response.data
             })  
             
        })
        .catch((error) => {
          alert("bookings is Not Added ");
        })
       
      }


      bookTable(){

        window.location="/table"
    

      }


    render() {
        return (
            <div>
                <h1> Booking List </h1>
                <hr />
                <table class="table table-striped">
  
    <tr>
      <th scope="col">Phone Number</th>
      <th scope="col">date</th>
      <th scope="col">time</th>
      <th scope="col">Number In Party</th>
      <th scope="col">Notes</th>
     
    </tr>
      {
          this.state.bookings.map((booking) =>(
              <tr key={booking.id}>
                  <td>{booking.phoneNumber}</td>
                  <td>{booking.date}</td>
                  <td>{booking.time}</td>
                  <td>{booking.numberInParty}</td>
                  <td>{booking.notes}</td>
              </tr>
          ))
      }
   
</table>
    <div>
      <button onClick={this.bookTable}> Book Table  </button>
    </div>
            </div>
        );
    }
}

export default BookingForm;