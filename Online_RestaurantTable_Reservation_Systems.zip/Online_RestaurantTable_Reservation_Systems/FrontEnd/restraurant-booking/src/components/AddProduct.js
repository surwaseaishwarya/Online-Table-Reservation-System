import React, { Component } from 'react';
import Header from './Header';

class AddProduct extends Component {

  constructor(){
      super();
           this.state={
            bookings:null
           }
    
  }

  componentDidMount(){
      fetch('http://localhost:8080/bookings').then((res)=>{
          res.json().then((result) =>{
                       console.warn(result.data)
                       this.setState({bookings:result.data})
          })   
         })
        }

    render() {
        return (

            <div>
                <Header/>
                <h1>add product......</h1>
                <h1> 
                   {
                         this.state.bookings  ?
                        this.state.bookings.map((item,i)=>
                        <div>
                           <p> {i} -- {item.id} </p>
                        </div>
                        )
                         :
                         null
                   } 
                </h1>
            </div>
        );
    }
}

export default AddProduct;