import React, { Component,useEffect,useState } from 'react';
import {useHistory} from 'react-router-dom'

import Header from './Header'

function Protected(props) {
   
    let Cmp=props.Cmp         // use of protected route and they should be redirect .........
    const history=useHistory()
    useEffect(()=>{

        if(!localStorage.getItem("user"))
        {
            history.push("/register")       // redirect .......... to  /add after login .......
        }

        // without login we cannot move to the page add / update page /..........
    },[])
        return (
            <div>
                <Cmp/>
                
            </div>
        );
   
}

export default Protected;