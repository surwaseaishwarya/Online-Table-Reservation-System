import React, { Component,useState,useEffect } from 'react';
import {useHistory} from 'react-router-dom';
import Header from './Header'
function Register()  {

    useEffect(()=>{

        if(localStorage.getItem("user"))
        {
            history.push("/add")       // redirect .......... to  /add after register .......
        }

    },[])

const [name,setName]=useState("")
const [phoneNumber,setPhoneNumber]=useState("")
const [email,setEmail]=useState("")
const [password,setPassword]=useState("")





   const history=useHistory()

async function signUp() {

    
     let item={name,phoneNumber,email,password}
     console.warn(item)

      

     // fetch api use hare  ..........
    let result = await fetch("http://localhost:8080/users",{
         method: "POST",
         body: JSON.stringify(item),
         headers: {
            "Content-Type": "application/json" ,
            "Accept": "application/json"
         }
     })
     result = await result.json()
     debugger
     localStorage.setItem("user", JSON.stringify(result))
     // redirect to the home page
       history.push("/add") 
       //let redirectURL = "/table?id"=result.id;
      // history.push(redirectURL)

       


 }

        return (
            <>
            <div><Header/></div>

            <div className="col-sm-6 offset-sm-3">
                <h1>Register page</h1>
                <input type = 'text' value ={name} onChange={(e)=>setName(e.target.value)} className='form-control' placeholder="Enter the name"></input><br />
                <input type = 'text' value={phoneNumber}  onChange={(e)=>setPhoneNumber(e.target.value)} className='form-control' placeholder="Enter the phoneNumber"></input><br />
                <input type = 'text' value={email} onChange={(e)=>setEmail(e.target.value)} className='form-control' placeholder="Enter the email"></input><br />
                <input type = 'password' value={password} onChange={(e)=>setPassword(e.target.value)} className='form-control' placeholder="Enter the password"></input><br />
               <button onClick={signUp} className='btn btn-primary'>Sign Up</button>
                
                

            </div>
            </>
        );
  
}

export default Register;
