import React, { Component } from "react";
import axios from 'axios';
class BookingDetails extends Component {

     constructor(props) {
         super(props);
         this.state={
          
          phoneNumber:'',
          date:'',
          time:'',
          notes:'',
          numberInParty:''
         
         };
         
  
    }



    onChangeHandler = (e) => {
      /*
        Because we named the inputs to match their
        corresponding values in state, it's
        super easy to update the state
      */
      this.setState({ [e.target.name]: e.target.value });
    }


    onSubmitHandler = (e) => {
      e.preventDefault();
       console.log(this.state);
            
       // debugger

       let usr=localStorage.getItem("user");
       var userId = JSON.parse(usr).id;
   
      // get our form data out of state
      const { phoneNumber, date, time ,notes,numberInParty } = this.state;
      axios
      .post(`http://localhost:8080/bookings/${userId}`, this.state)
        .then((result) => {
          //access the results here....
              console.log(result.data);
                  
        })
        .catch((error) => {
          alert("NOT WORKING ......")
        });
    }



  render() {
    const{phoneNumber,date,time,notes,numberInParty}=this.state;
    return (
      <div >
        <h1>   Booking details ..........</h1>
        <b></b><hr/><b></b>
        <form onSubmit={this.onSubmitHandler}>

          <div className="row">
            <div className="col-sm-4">
              <lable> Phone Number : </lable>
            </div>
            <div className="col-sm-4">
              <input type="text" name="phoneNumber"  className="form-control" maxLength="10" placeholder="Enter the phone number"></input>
            </div>
          </div> <br/>

          <div className="row">
            <div className="col-sm-4">
              <lable> Date : </lable>
            </div>
            <div className="col-sm-4">
              <input type="text" name="date"  className="form-control" placeholder="Enter the date "></input>
            </div>
          </div><br/>
          <div className="row">
            <div className="col-sm-4">
              <lable> Time : </lable>
            </div>
            <div className="col-sm-4">
              <input type="text" name="time"  className="form-control" placeholder="Enter the time"></input>
            </div>
          </div><br/>
          <div className="row">
            <div className="col-sm-4">
              <lable> Notes : </lable>
            </div>
            <div className="col-sm-4">
              <input type="text" name="notes" value={notes} onChange={this.onChangeHandler} className="form-control" placeholder="Enter the any Notes"></input>
            </div>
          </div><br/>

          <div className="row">
            <div className="col-sm-4">
              <lable> Number In Party :</lable>
            </div>
            <div className="col-sm-4">
              <input type="text" name="numberInParty"  className="form-control" placeholder="Enter the number in party"></input>
            </div>
          </div><br/>
          <button type="submit"   class="btn btn-primary">Submit</button>
        </form>
      </div>
    );
  }
}

export default BookingDetails;
