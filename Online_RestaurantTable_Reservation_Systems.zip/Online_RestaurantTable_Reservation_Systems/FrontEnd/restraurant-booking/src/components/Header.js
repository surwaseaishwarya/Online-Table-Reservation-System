import React from "react";
import { Navbar, Nav, NavDropdown } from "react-bootstrap";
import { Link,useHistory } from "react-router-dom";
 function Header() {

   let user = JSON.parse(localStorage.getItem('user'))

   console.log(user)
   const history =useHistory()

     // function for logout  feature ssssssss.....................
       
       function logout(){

        localStorage.clear();
           history.push("/register")

       }


  return (
    <div>
      <Navbar bg="dark" variant="dark">
        <Navbar.Brand href="/home">Restraurent System</Navbar.Brand>
        <Nav className="mr-auto navbar_wrapper">
          {
           
           localStorage.getItem("user") ?
           <>
              <Link to="/add"> Add product </Link>
              <Link to="/update"> Update </Link>
             
              <Link to="/table"> Table </Link>
              
           </>
               :

               <>
               
                    <Link to="/login"> Login </Link>
                    <Link to="/register"> Register </Link>
                    <Link to="/about"> About </Link>
               </>

          }

        </Nav>
        {/* logout features in react aftre login it must show / there is use of ternary operator in that case  */}
        {localStorage.getItem('user')         ?              
        <Nav>
               <NavDropdown title={user && user.name} >
                 <NavDropdown.Item onClick={logout}>Logout</NavDropdown.Item>         
               </NavDropdown>

        </Nav>


        :  null 
        }

      </Navbar>
    </div>
  );
}
export default Header;