import React from "react";

const About = () => (
  <div>
    <h1>About O.R.A.B</h1>
    <p>O.R.A.B is the 'Online Restaurant Application for Bookings system.</p>
    <ul id="datalist">
    <li>Aishwarya Surwase</li>
    <li>Prakash Bohara</li>
    </ul>
  </div>
);

export default About;