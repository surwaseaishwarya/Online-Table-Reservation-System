import React from "react";
import Header from "./Header"
const Home = () => (
  <div>
    <h1>Home</h1>
  
    <p>O.R.A.B  (online Restaurant Booking System ..)</p>
  </div>
);

export default Home;