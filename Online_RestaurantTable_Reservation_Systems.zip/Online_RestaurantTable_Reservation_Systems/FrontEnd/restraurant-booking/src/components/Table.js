import React, { Component } from "react";
import {Link} from "react-router-dom"
import Header from "./Header";
import axios from "axios";
import { Redirect } from "react-router";
class Table extends Component {
  constructor() {
    super();
    this.state = {
      tables: [],

    };
            
  }



  componentDidMount() {

    axios.get("http://localhost:8080/restaurant_tables")
    .then((response) => {
         this.setState({
           tables:response.data
         })  
         
    })
    .catch((error) => {
      alert("Table is Not Added ");
    })
   
  }


 // id will stored for booking  and update table id into booking 
 updateBooking(tableId){

 // debugger;

  let usr=localStorage.getItem("user");
  var userId = JSON.parse(usr).id;
    axios.put(`http://localhost:8080/bookings/${tableId}/${userId}`).then(response => {
      
              console.log("update booking .......")
              window.location="/bookings/"+userId;

    })
  //alert(1)
}



  render() {
   const{tables}=this.state;
      return (
        <div>
          <Header />
          <h1> All  Restaurant_Tables  .... </h1>
          <table class="table table-striped">
  
    <tr>
      <th scope="col">id</th>
      <th scope="col">Table No</th>
      <th scope="col">Seating </th>
      <th scope="col">Actions </th>
    </tr>
      {
          this.state.tables.map((table) =>(
              <tr key={table.id}>
                  <td >
                    {table.id}
                  </td>
                  <td>{table.tableNumber}</td>
                  <td>{table.seating}</td>
                  <td>
                     <button onClick={()=>this.updateBooking(table.id)}> Book now </button> 
                  </td>
              </tr>
          ))
      }
   
</table>

        </div>
      );
    }
  }


export default Table;
