import logo from './logo.svg';
import './App.css';
import { BrowserRouter,Route,Switch} from 'react-router-dom';

import { Redirect } from 'react-router'
import Login from './components/Login';
import Home from './components/Home';
import Register from './components/Register';
import AddProduct from './components/AddProduct';
import Table from './components/Table';
import About from './components/About';
import UpdateProduct from './components/UpdateProduct';
import Protected from './components/Protected';
import BookingForm from './components/BookingForm';
import BookingDetails from './components/BookingDetails'
function App() {
  return (
    <div className="App">
      <BrowserRouter> 
     <Switch>

      <Route path="/login">
              <Login />
      </Route>
      <Route path="/">
              <Home />
      </Route>
      <Route path="/register">
              <Register />
      </Route>
      <Route path="/add">
              {/* <AddProduct /> */}
              <Protected Cmp={AddProduct}  />  
                                                          
      </Route>
      <Route path="/update">
              {/* <UpdateProduct /> */}
              <Protected Cmp={UpdateProduct}/>   
      </Route>
      <Route path="/about">
             <About/>  
      </Route>
      <Route path="/table">
              {/* <UpdateProduct /> */}
              <Protected Cmp={Table}/>   
      </Route>
      <Route path="/bookings/:id">
              <BookingForm />
      </Route>

       <Route path="/bookings">
            <BookingDetails/>
       </Route>
      </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
