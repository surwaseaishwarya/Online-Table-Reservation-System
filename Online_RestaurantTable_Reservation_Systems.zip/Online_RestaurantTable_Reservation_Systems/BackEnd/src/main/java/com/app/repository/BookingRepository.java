package com.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Booking;
import com.app.pojos.RestaurantTable;
import com.app.pojos.User;

@Repository
@Transactional
public interface BookingRepository extends JpaRepositoryImplementation<Booking, Long>{

	
	
	//1]
	@Query(value = "SELECT * FROM bookings b WHERE b.table_id=:id and b.date>=CURRENT_DATE", nativeQuery = true)
	  List<Booking> findBookingByTableId(Long id);
	
	
	
	
	//2]
	@Query(value="select * from bookings b where b.user_id=:id",nativeQuery = true)
	public List<Booking> listBookingByuser(Long id);
	
	
	
	//3]
	// update booking ........
	
	@Modifying
	@Query(value="update bookings set table_id=:tableId where user_id=:userId",nativeQuery = true)
	public void updateBooking(Long tableId,Long userId);
	
	
	
	
	// 4] get All booking for admin
	@Query(value="select * from bookings",nativeQuery = true)
	public List<Booking> getAllBooking();
	
	
	
	
	
	
	
}
