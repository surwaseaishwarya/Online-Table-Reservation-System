package com.app.services;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Booking;
import com.app.pojos.RestaurantTable;

@Service 
@Transactional
public interface BookingService {
	
	
	//list all ........
	public List<Booking> getBookings();
	
	// user id ,table id 
	public Booking createBooking(Booking booking,Long userId,Long tableId);

     // user id 
	public Booking createBooking(Booking booking,Long userId);

	
	// booking by id ..........
	public Booking getBookingByuserId(Long id);


	// delet booking by id .........
	public void deleteBookingById(Long id);
	
	
	// update  user booking 
	

	
	
	
}



