package com.app.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.exception.ResourceNotFound;
import com.app.pojos.Booking;
import com.app.pojos.RestaurantTable;
import com.app.pojos.User;
import com.app.repository.BookingRepository;
import com.app.repository.RestaurentTablesRepository;
import com.app.repository.UserRepository;

@Service
@Transactional
public class BookingServiceImpl implements BookingService  {
	
	
	@Autowired
	BookingRepository bookingRepo;
	
	@Autowired
	UserRepository userRepo;
	
	
	@Autowired
	private RestaurentTablesRepository restraurantTablesRepo;
	
  // 
	@Override
	public List<Booking> getBookings() {

            return  bookingRepo.findAll();
		
		
	}


	@Override
	public Booking getBookingByuserId(Long id) {
		
		 Optional<Booking> findById = bookingRepo.findById(id);
		 
		 Booking booking=findById.get();
		 return booking;
	}


	// delete   by table id  ...........
	
	@Override
	public void deleteBookingById(Long id) {
		
		
		bookingRepo.deleteById(id);
	
	}

	
//              create bookings by table id ,user id ..............
	@Override
	public Booking createBooking(Booking booking, Long userId,Long tableId) {

		User user = userRepo.findById(userId).orElseThrow(() -> new ResourceNotFound("Invalid User ID"));
		RestaurantTable table = restraurantTablesRepo.findById(tableId).orElseThrow(() -> new ResourceNotFound("Invalid Room ID"));
		
		user.addBooking(booking);
		table.addBooking(booking);
		
		
		return bookingRepo.save(booking);
	}


	@Override
	public Booking createBooking(Booking booking, Long userId) {

		User user = userRepo.findById(userId).orElseThrow(() -> new ResourceNotFound("Invalid User ID"));
		user.addBooking(booking);
		
		return null;
	}


	
	

	
	
	
	
	
	
	
	
	
	  
	

}
